title: Gradle 版本更新
date: '2019-12-13 22:26:39'
updated: '2019-12-13 22:27:16'
tags: [AndroidStudio]
permalink: /articles/2019/12/13/1576247199702.html
---
![Snipaste20191213222556.png](https://img.hacpai.com/file/2019/12/Snipaste20191213222556-8de1aac7.png)

